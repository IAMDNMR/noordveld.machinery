# Runnable isolated application

This target is an actual local application, separate from the React screen preview.
It uses Python 3.12+ standard-library HTTP and SQLite; no npm install is needed.

Windows PowerShell:
  python runtime/server.py --demo --data-dir "$env:TEMP/studio-runtime-myapp" --port 8091
Unix:
  python runtime/server.py --demo --data-dir /tmp/studio-runtime-myapp --port 8091

Open http://127.0.0.1:8091. Choose an explicitly listed synthetic application identity.
The database persists in the supplied directory across reloads and server restarts.
Only approved specifications can launch. Reusing a database with a changed specification
is refused: migrations must be reviewed, never inferred. This is a local deployment target,
not production identity or hosting. Demo identities are never a production login strategy.

Run independent generated tests: python -m unittest discover -s runtime -p test_runtime.py -v

API: GET /api/application, GET/POST /api/records/{entity}, POST /api/records/{entity}/{id},
GET/POST /api/instances, POST /api/instances/{id}/advance, GET /api/instances/{id}/history.
Record writes submit {data, expected_revision}; process actions submit {expected_revision,links}.
Organization and role come exclusively from the server session. State and rule results cannot
be supplied by the client. Each write is atomic and audited. No deletion endpoint is generated.
Unsupported prose rules fail closed; inspect schema.json unsupported before claiming coverage.
System-generated keys are generated on create. Records of entities listed in schema.json imports come from
another system; no import adapter is connected, so the demo "Data import stand-in" identity enters them by hand
(audited as record.import). It is not a business role and cannot perform process steps.
Assumption bindings stay assumptions: demo execution does not establish company policy.

## Moving data to another revision

Keep the previous package and database for rollback. Stop application writers before promotion.
Preview: python runtime/migrate.py --previous-schema ../previous/runtime/schema.json --source ../previous-data/application.sqlite
Apply compatible changes to a NEW file: append --apply --target ../next-data/application.sqlite --actor operator-name
Only compatible optional-field/data-preserving changes are accepted. Changed rules, permissions,
relationships, workflows, required fields or runtime versions need a reviewed custom migration.
The source is opened read-only, sessions are cleared in the copy, and migration events are recorded.
Validate the new application before redirecting traffic. Roll back using the previous package and
its unchanged database; reconcile any writes made after promotion before switching back.
