/* Generated application client. All mutations use the same-origin runtime API; the server decides every permission. */
const root = document.getElementById("app");
root.removeAttribute("aria-live");
let dirty = false,
  savingRecord = false;
const desktopNavigation = window.matchMedia?.("(min-width:761px)");
desktopNavigation?.addEventListener?.("change", (event) =>
  document
    .querySelector(".mobile-navigation")
    ?.toggleAttribute("open", event.matches),
);
window.addEventListener("beforeunload", (event) => {
  if (dirty) {
    event.preventDefault();
    event.returnValue = "";
  }
});
let application,
  instances = [],
  route = { page: "home" };
const cache = new Map();

/* How this application presents itself. Decided by the generator from the specification (schema.json "presentation"). */
const PROFILES = {
  operations: {
    home: "Control tower",
    homeIntro:
      "Live work across your processes: what is moving, what is stuck and what needs you now.",
    tasks: "My work queue",
    board: true,
    icon: "truck",
  },
  service: {
    home: "Service desk",
    homeIntro: "Open cases by stage, and the ones waiting for you.",
    tasks: "My queue",
    board: true,
    icon: "support",
  },
  requests: {
    home: "My requests",
    homeIntro: "Requests you started and approvals waiting for you.",
    tasks: "Waiting for my approval",
    board: false,
    icon: "file",
  },
  warehouse: {
    home: "Warehouse floor",
    homeIntro:
      "What is waiting to be allocated, picked, packed or counted, and what is short.",
    tasks: "My pick and pack work",
    board: true,
    icon: "package",
  },
  commerce: {
    home: "Order desk",
    homeIntro:
      "Orders by stage: what is waiting for stock, payment or confirmation.",
    tasks: "Orders needing me",
    board: true,
    icon: "basket",
  },
  procurement: {
    home: "Purchasing",
    homeIntro: "Requisitions, approvals and goods still to arrive.",
    tasks: "Waiting for me",
    board: false,
    icon: "basket",
  },
  sales: {
    home: "Sales pipeline",
    homeIntro:
      "Opportunities by stage, and the discounts waiting for a decision.",
    tasks: "My deals",
    board: true,
    icon: "chart",
  },
  finance: {
    home: "Billing desk",
    homeIntro: "Invoices to draft, review, issue and collect.",
    tasks: "Invoices needing action",
    board: true,
    icon: "payment",
  },
  people: {
    home: "People and time",
    homeIntro: "Leave requests, approvals and the team's tasks.",
    tasks: "Waiting for my decision",
    board: false,
    icon: "users",
  },
  maintenance: {
    home: "Work desk",
    homeIntro:
      "Work orders from planning to inspection, and the parts they wait for.",
    tasks: "My work orders",
    board: true,
    icon: "repair",
  },
  workspace: {
    home: "Overview",
    homeIntro:
      "Start with the next action, or open the records behind a process.",
    tasks: "My tasks",
    board: false,
    icon: "home",
  },
};
const profile = () =>
  PROFILES[application?.presentation?.archetype] ?? PROFILES.workspace;
// Semantic SVG icons also ship in the standalone application: no font or network dependency.
const ICON_PATHS = {
  home: ["M3 10l9-7 9 7v11h-6v-7H9v7H3z"],
  users: [
    "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
    "M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0",
    "M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75",
  ],
  support: [
    "M3 14v-3a9 9 0 0 1 18 0v3",
    "M3 12h4v8H3zM17 12h4v8h-4zM17 20v2h-5",
  ],
  basket: ["M2 3h3l3 12h11l3-8H6", "M10 20h.01M18 20h.01"],
  chart: ["M3 3v18h18", "M7 15l4-5 4 3 5-7"],
  file: ["M5 2h10l4 4v16H5z", "M14 2v5h5M8 12h8M8 16h6"],
  workflow: ["M3 3h6v6H3zM15 15h6v6h-6zM15 3h6v6h-6z", "M9 6h6M6 9v9h9"],
  carrier: [
    "M3 21V3h12v18M15 9h6v12M7 7h4M7 11h4M7 15h4M7 19h4M18 13h1M18 17h1",
  ],
  vehicle: ["M5 8l2-5h10l2 5M3 8h18v10H3zM5 18v3M19 18v3M7 12h.01M17 12h.01"],

  truck: [
    "M1 4h13v12H1z",
    "M14 8h5l4 4v4h-9",
    "M7 18a2 2 0 1 1-4 0 2 2 0 0 1 4 0",
    "M21 18a2 2 0 1 1-4 0 2 2 0 0 1 4 0",
  ],
  calendar: ["M4 5h16v16H4z", "M4 10h16", "M8 2v6M16 2v6"],
  tracking: [
    "M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0",
    "M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0",
  ],
  proof: ["M5 2h10l4 4v16H5z", "M14 2v5h5", "M8 14l3 3 5-6"],
  package: ["M3 6l9-4 9 4v12l-9 4-9-4z", "M3 6l9 5 9-5M12 11v11"],
  review: ["M12 2l9 4v6c0 6-9 10-9 10S3 18 3 12V6z", "M7 12l3 3 7-7"],
  payment: ["M2 5h20v15H2z", "M2 10h20M6 16h4"],
  exception: ["M12 3l10 18H2z", "M12 9v5M12 17v1"],
  task: ["M5 4h14v18H5z", "M9 2h6v5H9z", "M8 12h8M8 16h6"],
  repair: ["M14 3a6 6 0 0 0-6 8L2 17l5 5 6-6a6 6 0 0 0 8-7l-4 4-5-5 4-4z"],
  search: ["M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0", "M15 15l7 7"],
};
function taskIconName(label) {
  const text = label.toLowerCase();
  if (/proof|pod\b/.test(text)) return "proof";
  if (/tracking|track\b/.test(text)) return "tracking";
  if (/exception|resolv|shortage|overload/.test(text)) return "exception";
  if (/approv|review|decide|inspect/.test(text)) return "review";
  if (/payment|invoice/.test(text)) return "payment";
  if (/plan|schedule|leave/.test(text)) return "calendar";
  if (/carrier/.test(text)) return "carrier";
  if (/vehicle/.test(text)) return "vehicle";
  if (/dispatch|ship|transport/.test(text)) return "truck";
  if (/pick|pack|stock|goods/.test(text)) return "package";
  if (/repair|rework|carry out/.test(text)) return "repair";
  if (/find|search/.test(text)) return "search";
  if (/customer|employee|person|people|contact|team|user/.test(text))
    return "users";
  if (/order|purchas|requisition|procure/.test(text)) return "basket";
  if (/report|sales|opportunit/.test(text)) return "chart";
  if (/document|request|claim/.test(text)) return "file";
  return "task";
}
function taskIcon(label) {
  return icon(taskIconName(label));
}
function icon(name) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  for (const [key, value] of Object.entries({
    viewBox: "0 0 24 24",
    width: "20",
    height: "20",
    fill: "none",
    stroke: "currentColor",
    "stroke-width": "1.6",
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "aria-hidden": "true",
    class: "runtime-task-icon",
  }))
    svg.setAttribute(key, value);
  for (const d of ICON_PATHS[name] || ICON_PATHS.task) {
    const path = document.createElementNS(svg.namespaceURI, "path");
    path.setAttribute("d", d);
    svg.append(path);
  }
  return svg;
}
// Task intent comes from the process, independently of the project's industry.
const TASK_INTENT = {
  form: [
    "Capture the details",
    "Choose the records needed for this task. Open a record to review or update its details before continuing.",
  ],
  search: [
    "Find the right record",
    "Select the records that belong to this process before moving forward.",
  ],
  review: [
    "Review the information",
    "Check the linked records and business criteria before completing this review.",
  ],
  approval: [
    "Review and decide",
    "Check the supporting records before completing this approval. The configured approval criteria apply.",
  ],
  action: [
    "Complete this task",
    "Check the linked information, then complete the action to move work forward.",
  ],
  exception: [
    "Resolve the exception",
    "Review the affected records and follow the recovery path defined for this process.",
  ],
  end: [
    "Process outcome",
    "This process path has ended. Its records and history remain available below.",
  ],
};

function el(tag, text, attributes = {}) {
  const node = document.createElement(tag);
  if (text !== null && text !== undefined) node.textContent = text;
  for (const [key, value] of Object.entries(attributes))
    if (value !== undefined && value !== null && value !== false)
      node.setAttribute(key, value);
  return node;
}
function append(parent, ...children) {
  for (const child of children) if (child) parent.append(child);
  return parent;
}
function button(text, action, className = "", label) {
  const node = el("button", text, {
    type: "button",
    class: className,
    "aria-label": label,
  });
  node.addEventListener("click", async (event) => {
    event.stopPropagation();
    node.disabled = true;
    try {
      await action();
    } catch (error) {
      notify(error.message, true);
    } finally {
      node.disabled = false;
    }
  });
  return node;
}
async function api(path, body) {
  let response;
  try {
    response = await fetch(
      "/api" + path,
      body === undefined
        ? {}
        : {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          },
    );
  } catch {
    throw new Error(
      "The application server is unavailable. Your input is kept; retry when it is running.",
    );
  }
  const data = await response
    .json()
    .catch(() => ({ error: "Unexpected response from the server" }));
  if (!response.ok) {
    const error = new Error(
      data.error +
        (data.details
          ? ": " + data.details.map((item) => item.message).join(" ")
          : ""),
    );
    error.status = response.status;
    error.details = data.details || [];
    throw error;
  }
  return data;
}
function notify(text, error = false) {
  const area = document.getElementById("notification");
  if (!area) return;
  area.textContent = text;
  area.setAttribute("role", error ? "alert" : "status");
  area.className = error ? "notice error" : "notice success";
  if (!error)
    setTimeout(() => {
      if (area.textContent === text) {
        area.textContent = "";
        area.className = "notice";
      }
    }, 6000);
}
async function records(entity) {
  if (!cache.has(entity)) cache.set(entity, await api("/records/" + entity));
  return cache.get(entity);
}
function labelled(text, input, hint) {
  const label = el("label", text);
  append(label, input, hint ? el("small", hint) : null);
  return label;
}
const roleName = (id) =>
  (id && application.roles?.[id]) ||
  (id ? id.replace(/^role_/, "").replaceAll("_", " ") : "nobody yet");
/* Time convention (the server's): a date is a calendar day "YYYY-MM-DD" and is never shifted by a time zone; a datetime is an
   instant, sent and stored as UTC ("…Z") and shown in the viewer's own time zone. */
const ZONE =
  Intl.DateTimeFormat().resolvedOptions().timeZone || "your local time zone";
// dateStyle/timeStyle cannot be combined with timeZoneName, so the parts are named one by one.
const time = (iso) => {
  const date = new Date(iso);
  return isNaN(date)
    ? iso
    : date.toLocaleString(undefined, {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        timeZoneName: "short",
      });
};
const day = (value) => {
  const [y, m, d] = String(value).split("-").map(Number);
  const date = new Date(y, m - 1, d);
  return isNaN(date)
    ? value
    : date.toLocaleDateString(undefined, { dateStyle: "medium" });
};
const pad = (n) => String(n).padStart(2, "0");
function toLocalInput(iso) {
  const d = new Date(iso);
  return isNaN(d)
    ? ""
    : `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function fromLocalInput(value) {
  const d = new Date(value);
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(value) || isNaN(d)) return null;
  return d.toISOString();
}
const workflowOf = (instance) =>
  application.workflows.find((w) => w.id === instance.workflow);
const stateLabel = (workflow, id) =>
  workflow?.states.find((s) => s.id === id)?.label ?? id;

/* Steps in the order work reaches them (breadth-first from the start); exceptions after the main flow. */
function ordered(workflow) {
  const start = workflow.states.find((s) => s.kind === "start");
  const seen = new Set(start ? [start.id] : []),
    order = start ? [start] : [],
    queue = start ? [start.id] : [];
  while (queue.length) {
    const current = queue.shift();
    for (const edge of workflow.transitions.filter(
      (e) => e.source === current,
    )) {
      if (seen.has(edge.target)) continue;
      seen.add(edge.target);
      queue.push(edge.target);
      order.push(workflow.states.find((s) => s.id === edge.target));
    }
  }
  const rest = workflow.states.filter((s) => !seen.has(s.id));
  const main = [...order, ...rest].filter(Boolean);
  return [
    ...main.filter((s) => s.kind !== "exception"),
    ...main.filter((s) => s.kind === "exception"),
  ];
}
/* The columns of a board: every step where work waits (not automatic decisions, not the start). */
const columnsOf = (workflow) =>
  ordered(workflow).filter((s) => s.kind !== "start" && s.kind !== "branch");
function statusOf(instance) {
  if (instance.step.kind === "end")
    return {
      text:
        instance.step.outcome === "success" || !instance.step.outcome
          ? "Completed"
          : instance.step.outcome === "cancelled"
            ? "Cancelled"
            : "Closed",
      tone:
        instance.step.outcome && instance.step.outcome !== "success"
          ? "muted"
          : "done",
    };
  if (instance.step.kind === "exception")
    return { text: "Exception", tone: "danger" };
  if (instance.blocked?.length)
    return {
      text: instance.blocked.some((b) => b.decision)
        ? "Waiting on a decision"
        : "Not executable yet",
      tone: "blocked",
    };
  if (instance.can_act) return { text: "Your action", tone: "action" };
  return { text: "With " + roleName(instance.step.role_id), tone: "waiting" };
}
function pill(text, tone) {
  return el("span", text, { class: "pill pill--" + tone });
}
function linkSummary(instance) {
  const parts = [];
  for (const [entityId, recordId] of Object.entries(instance.links || {})) {
    const entity = application.entities.find((e) => e.id === entityId);
    const row = cache.get(entityId)?.find((r) => r.id === recordId);
    parts.push(
      (entity?.name || entityId) +
        " " +
        (row ? recordLabel(entity, row) : recordId.slice(0, 6)),
    );
  }
  return parts.join(" · ") || "No records linked yet";
}
function workTitle(instance) {
  const workflow = workflowOf(instance);
  const priorities = [
    ...new Set(
      (workflow?.states || []).flatMap((step) => step.writes_entity_ids || []),
    ),
  ];
  const id =
    priorities.find((id) => instance.links?.[id]) ||
    Object.keys(instance.links || {})[0];
  if (!id) return workflow?.name || "Unlinked work item";
  const entity = application.entities.find((item) => item.id === id);
  const row = cache.get(id)?.find((item) => item.id === instance.links[id]);
  return `${entity?.name || "Record"} ${row ? recordLabel(entity, row) : instance.links[id].slice(0, 6)}`;
}

/* ── sign in ─────────────────────────────────────────────────────────── */
async function signIn() {
  if (savingRecord) return notify("Please wait until saving finishes.");
  if (dirty && !(await confirmDiscard())) return;
  dirty = false;
  root.replaceChildren();
  const users = await api("/demo-users");
  const card = el("section", null, { class: "login" });
  append(
    card,
    el("p", "DEMONSTRATION", { class: "eyebrow" }),
    el("h1", "Choose a role"),
    el("p", "Explore the application with the role you want to review.", {
      class: "muted",
    }),
  );
  const organization = el("select", null, { "aria-label": "Demo workspace" });
  for (const tenant of [...new Set(users.map((user) => user.tenant))])
    organization.append(
      el("option", tenant.replace("demo_", "").replaceAll("_", " "), {
        value: tenant,
      }),
    );
  if (organization.options.length > 1)
    card.append(labelled("Workspace", organization));
  const list = el("ul", null, {
    class: "identities",
    "aria-label": "Demonstration identities",
  });
  const supporting = el("details", null, { class: "supporting-roles" });
  const extra = el("ul", null, { class: "identities" });
  append(supporting, el("summary", "Supporting roles"), extra);
  const draw = () => {
    list.replaceChildren();
    extra.replaceChildren();
    const selected = users.filter((user) => user.tenant === organization.value);
    const hasPrimary = selected.some((user) => user.primary === true);
    for (const user of selected) {
      const role = user.name.split(" · ")[0];
      const item = button(
        "",
        async () => {
          await api("/login", { user_id: user.id });
          await load();
        },
        "identity",
        `Sign in as ${role}, ${user.tenant.replace("demo_", "").replaceAll("_", " ")}`,
      );
      append(item, el("strong", role), icon("users"));
      const target = !hasPrimary || user.primary ? list : extra;
      target.append(append(el("li"), item));
    }
    supporting.hidden = !extra.childNodes.length;
  };
  organization.addEventListener("change", draw);
  draw();
  append(
    card,
    list,
    supporting,
    el("p", "Demo access only. Production sign-in is not connected.", {
      class: "muted small",
    }),
    el("p", "", { id: "notification", class: "notice" }),
  );
  root.append(card);
}

async function load() {
  cache.clear();
  application = await api("/application");
  instances = await api("/instances");
  const presentation = application.presentation || {};
  document.body.dataset.archetype = presentation.archetype || "workspace";
  if (presentation.accent) {
    document.body.style.setProperty("--accent", presentation.accent);
    document.body.style.setProperty(
      "--accent-ink",
      accentInk(presentation.accent),
    );
  }
  document.title = application.name;
  // Linked record names are shown on cards; load the ones this role can read, quietly.
  await Promise.all(
    [...new Set(instances.flatMap((i) => Object.keys(i.links || {})))].map(
      (id) => records(id).catch(() => []),
    ),
  );
  route = { page: "home" };
  await render();
}
async function go(next) {
  if (savingRecord) return notify("Please wait until saving finishes.");
  if (dirty && !(await confirmDiscard())) return;
  dirty = false;
  route = next;
  await render();
  document.querySelector("main")?.focus();
}
function confirmDiscard() {
  return new Promise((resolve) => {
    const previousFocus = document.activeElement;
    const dialog = el("dialog", null, {
      class: "discard-dialog",
      "aria-labelledby": "discard-title",
      "aria-describedby": "discard-description",
    });
    const finish = (discarded) => {
      dialog.close();
      dialog.remove();
      previousFocus?.focus();
      resolve(discarded);
    };
    append(
      dialog,
      el("h2", "Leave without saving?", { id: "discard-title" }),
      el(
        "p",
        "Your changes have not been saved. Keep editing to finish them, or discard them to leave this page.",
        { id: "discard-description" },
      ),
      append(
        el("div", null, { class: "form-actions" }),
        button("Keep editing", () => finish(false), "primary"),
        button("Discard changes", () => finish(true), "ghost"),
      ),
    );
    dialog.addEventListener("cancel", (event) => {
      event.preventDefault();
      finish(false);
    });
    document.body.append(dialog);
    dialog.showModal();
  });
}
function accentInk(hex) {
  if (!/^#[a-f0-9]{6}$/i.test(hex || "")) return "#ffffff";
  const channels = [1, 3, 5]
    .map((start) => parseInt(hex.slice(start, start + 2), 16) / 255)
    .map((value) =>
      value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4,
    );
  const luminance =
    channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
  return (luminance + 0.05) / 0.05 > 1.05 / (luminance + 0.05)
    ? "#000000"
    : "#ffffff";
}

/* ── shell ───────────────────────────────────────────────────────────── */
async function render() {
  root.replaceChildren();
  const shell = el("div", null, { class: "shell" }),
    rail = el("aside", null, { class: "rail" }),
    content = el("main", null, { tabindex: "-1", id: "main-content" });
  const brand = el("div", null, { class: "brand" });
  append(
    brand,
    append(
      el("span", null, { class: "brand__mark", "aria-hidden": "true" }),
      icon(profile().icon),
    ),
    append(
      el("div"),
      el("strong", application.name),
      el(
        "small",
        application.user.tenant.replace("demo_", "").replaceAll("_", " "),
      ),
    ),
  );
  const nav = el("nav", null, { "aria-label": "Application" });
  const link = (target, label, count) => {
    const active =
      route.page === target.page && (route.id ?? null) === (target.id ?? null);
    const node = button("", () => go(target), active ? "nav active" : "nav");
    if (active) node.setAttribute("aria-current", "page");
    append(
      node,
      append(
        el("span", null, { class: "nav-item-label" }),
        icon(
          target.page === "home"
            ? "home"
            : target.page === "tasks"
              ? "task"
              : target.page === "workflow"
                ? "workflow"
                : target.page === "about"
                  ? "file"
                  : taskIconName(label),
        ),
        el("span", label),
      ),
      count ? el("span", String(count), { class: "count" }) : null,
    );
    nav.append(node);
  };
  const mine = instances.filter((i) => i.can_act);
  link({ page: "home" }, profile().home);
  link({ page: "tasks" }, profile().tasks, mine.length);
  const open = (id) =>
    instances.filter((i) => i.workflow === id && i.step.kind !== "end").length;
  const visibleWorkflows = new Set(application.workflows.map((w) => w.id)),
    visibleEntities = new Set(application.entities.map((e) => e.id));
  const groups = (application.groups || [])
    .map((group) => ({
      ...group,
      workflow_ids: group.workflow_ids.filter((id) => visibleWorkflows.has(id)),
      entity_ids: group.entity_ids.filter((id) => visibleEntities.has(id)),
    }))
    .filter((group) => group.workflow_ids.length || group.entity_ids.length);
  if (groups.length > 1) {
    // One application built from several domains: each domain's processes and records are kept together, and the one that holds the page is open.
    for (const group of groups) {
      const holds =
        group.workflow_ids.includes(route.id) ||
        group.entity_ids.includes(route.id) ||
        (route.page === "instance" &&
          group.workflow_ids.includes(
            instances.find((i) => i.id === route.id)?.workflow,
          ));
      const section = el("details", null, {
        class: "nav-group",
        open: holds || groups.length <= 3 ? "open" : undefined,
      });
      append(section, el("summary", group.title));
      const inner = el("div");
      for (const id of group.workflow_ids) {
        const workflow = application.workflows.find((w) => w.id === id);
        const node = button(
          "",
          () => go({ page: "workflow", id }),
          route.page === "workflow" && route.id === id ? "nav active" : "nav",
        );
        append(
          node,
          append(
            el("span", null, { class: "nav-item-label" }),
            icon("workflow"),
            el("span", workflow.name),
          ),
          open(id) ? el("span", String(open(id)), { class: "count" }) : null,
        );
        inner.append(node);
      }
      for (const entity of primaryEntities().filter((e) =>
        group.entity_ids.includes(e.id),
      )) {
        const node = button(
          "",
          () => go({ page: "records", id: entity.id }),
          route.page === "records" && route.id === entity.id
            ? "nav active nav--record"
            : "nav nav--record",
        );
        append(
          node,
          append(
            el("span", null, { class: "nav-item-label" }),
            taskIcon(entity.name),
            el("span", entity.name),
          ),
        );
        inner.append(node);
      }
      section.append(inner);
      nav.append(section);
    }
  } else {
    if (application.workflows.length)
      nav.append(el("p", "PROCESSES", { class: "nav-label" }));
    for (const workflow of application.workflows)
      link(
        { page: "workflow", id: workflow.id },
        workflow.name,
        open(workflow.id),
      );
    nav.append(el("p", "RECORDS", { class: "nav-label" }));
    for (const entity of primaryEntities())
      link({ page: "records", id: entity.id }, entity.name);
  }
  nav.append(el("p", "THIS APPLICATION", { class: "nav-label" }));
  link({ page: "about" }, "What it can do");
  const navigation = el("details", null, {
    class: "mobile-navigation",
    open: desktopNavigation?.matches !== false ? "open" : undefined,
  });
  append(
    navigation,
    append(
      el("summary"),
      icon("workflow"),
      el("span", "Navigation"),
      el(
        "span",
        route.page === "home"
          ? profile().home
          : route.page === "tasks"
            ? profile().tasks
            : "Workspace",
        { class: "navigation-current" },
      ),
    ),
    nav,
  );
  append(
    rail,
    brand,
    navigation,
    el("p", "Application workspace", { class: "rail-footer" }),
  );
  const header = el("header", null, { class: "topbar" });
  append(
    header,
    el("span", application.presentation?.description || "", {
      class: "topbar__about",
    }),
    append(
      el("span", null, { class: "whoami" }),
      el("span", roleName(application.user.role), { class: "whoami__role" }),
      el(
        "span",
        application.user.tenant.replace("demo_", "").replaceAll("_", " "),
      ),
    ),
    button("Switch identity", signIn, "ghost"),
  );
  append(
    content,
    header,
    el("div", "", { id: "notification", class: "notice" }),
  );
  const body = el("div", null, { class: "page", "aria-busy": "true" });
  body.append(el("p", "Loading…", { class: "loading" }));
  append(content, body);
  append(shell, rail, content);
  root.append(
    el("a", "Skip to content", { href: "#main-content", class: "skip-link" }),
    shell,
  );
  try {
    const view = el("div");
    if (route.page === "about") await about(view);
    else if (route.page === "home") await home(view);
    else if (route.page === "tasks") await tasks(view);
    else if (route.page === "workflow")
      await workflowPage(
        view,
        application.workflows.find((w) => w.id === route.id),
      );
    else if (route.page === "instance")
      await instanceDetail(
        view,
        instances.find((i) => i.id === route.id),
      );
    else if (route.page === "records")
      await entityPage(
        view,
        application.entities.find((e) => e.id === route.id),
      );
    else if (route.page === "record")
      await recordForm(
        view,
        application.entities.find((e) => e.id === route.entity),
        route.id,
        route.task,
      );
    body.replaceChildren(...view.childNodes);
  } catch (error) {
    body.replaceChildren(
      el("div", error.message, { class: "notice error", role: "alert" }),
      button("Try again", render),
    );
  } finally {
    body.removeAttribute("aria-busy");
  }
}
/* Records this role works with first: the ones its own steps change, then the ones it reads, then the rest it may see. */
function primaryEntities() {
  const steps = application.workflows
    .flatMap((w) => w.states)
    .filter((s) => s.role_id === application.user.role);
  const weight = (entity) =>
    steps.some((s) => (s.writes_entity_ids || []).includes(entity.id))
      ? 0
      : steps.some((s) => (s.reads_entity_ids || []).includes(entity.id))
        ? 1
        : 2;
  return [...application.entities].sort(
    (a, b) => weight(a) - weight(b) || a.name.localeCompare(b.name),
  );
}
function heading(body, kicker, title, description, actions) {
  const head = el("div", null, { class: "page-head" });
  append(
    head,
    append(
      el("div"),
      el("p", kicker, { class: "eyebrow" }),
      el("h1", title),
      description ? el("p", description, { class: "intro" }) : null,
    ),
    actions
      ? append(el("div", null, { class: "page-head__actions" }), ...actions)
      : null,
  );
  body.append(head);
}

/* ── home ────────────────────────────────────────────────────────────── */
async function home(body) {
  const p = profile();
  heading(
    body,
    roleName(application.user.role).toUpperCase(),
    p.home,
    p.homeIntro,
    startButtons(),
  );
  const open = instances.filter((i) => i.step.kind !== "end");
  const stats = el("div", null, { class: "stats", role: "list" });
  for (const [label, value, tone] of [
    ["In progress", open.length, ""],
    [p.tasks, instances.filter((i) => i.can_act).length, "action"],
    [
      "Exceptions",
      open.filter((i) => i.step.kind === "exception").length,
      "danger",
    ],
    [
      "Completed",
      instances.filter((i) => i.step.kind === "end").length,
      "done",
    ],
  ]) {
    stats.append(
      append(
        el("article", null, {
          class: "stat",
          role: "listitem",
          "data-tone": value ? tone : "",
        }),
        el("span", label),
        el("strong", String(value)),
      ),
    );
  }
  body.append(stats);
  const grid = el("div", null, { class: "home-grid" });
  const queue = append(
    el("section", null, { class: "card home-queue" }),
    append(
      el("header", null, { class: "section-head" }),
      el("h2", p.tasks),
      el("span", String(instances.filter((i) => i.can_act).length), {
        class: "count",
      }),
    ),
  );
  const mine = instances.filter((i) => i.can_act).slice(0, 6);
  if (!mine.length)
    queue.append(
      empty(
        "Nothing is waiting for you.",
        application.workflows.some(canStart)
          ? "Start a process from the button above."
          : "Work arrives here when a process reaches a step your role performs.",
      ),
    );
  for (const instance of mine) queue.append(instanceRow(instance));
  const flows = append(
    el("section", null, { class: "card home-processes" }),
    el("h2", "Process overview"),
  );
  if (!application.workflows.length)
    flows.append(empty("No process is available to your role."));
  for (const workflow of application.workflows)
    flows.append(pipeline(workflow));
  append(grid, workOverview(), queue);
  body.append(grid);
  body.append(flows);
  if (application.unsupported.length) body.append(gaps());
}
/* Actual process instances, scoped by the server to the signed-in role and workspace. */
function workOverview() {
  const section = append(
    el("section", null, { class: "card work-overview" }),
    append(
      el("header", null, { class: "section-head" }),
      el("h2", "Recent work"),
      button("View all", () => go({ page: "tasks" }), "link"),
    ),
  );
  if (!instances.length)
    return append(
      section,
      empty(
        "No work started yet.",
        "Your processes will appear here as work begins.",
      ),
    );
  const table = el("table", null, { "aria-label": "Recent process activity" });
  append(
    table,
    append(
      el("thead"),
      append(
        el("tr"),
        ...["Work item", "Current stage", "Status"].map((text) =>
          el("th", text, { scope: "col" }),
        ),
      ),
    ),
  );
  const rows = el("tbody");
  for (const instance of instances.slice(0, 6)) {
    const status = statusOf(instance);
    const name = el("td");
    name.append(
      button(
        workTitle(instance),
        () => go({ page: "instance", id: instance.id }),
        "work-item",
        "Open work item: " + linkSummary(instance),
      ),
    );
    const state = append(
      el("td"),
      el("span", instance.step.label, { class: "strong" }),
      el(
        "small",
        instance.step.kind === "end"
          ? "Completed process"
          : roleName(instance.step.role_id),
        { class: "cell-secondary" },
      ),
    );
    rows.append(
      append(
        el("tr"),
        name,
        state,
        append(el("td"), pill(status.text, status.tone)),
      ),
    );
  }
  append(table, rows);
  return append(
    section,
    append(el("div", null, { class: "table-scroll" }), table),
  );
}
function canStart(workflow) {
  const start = workflow.states.find((s) => s.kind === "start");
  const first = workflow.transitions.find((e) => e.source === start?.id);
  const step = workflow.states.find((s) => s.id === first?.target);
  return step && step.role_id === application.user.role;
}
function startButtons() {
  return application.workflows.filter(canStart).map((workflow) =>
    button(
      "Start " + workflow.name.toLowerCase(),
      async () => {
        const result = await api("/instances", {
          workflow_id: workflow.id,
          links: {},
        });
        instances = await api("/instances");
        await go({ page: "instance", id: result.id });
        notify(
          "Started. Link the records this step works on, then complete it.",
        );
      },
      "primary",
    ),
  );
}
function pipeline(workflow) {
  const box = append(
    el("div", null, { class: "pipeline" }),
    append(
      el("div", null, { class: "pipeline__head" }),
      el("strong", workflow.name),
      button(
        "Open board",
        () => go({ page: "workflow", id: workflow.id }),
        "link",
      ),
    ),
  );
  const list = el("ol");
  for (const step of columnsOf(workflow).filter(
    (s) => s.kind !== "exception",
  )) {
    const count = instances.filter(
      (i) => i.workflow === workflow.id && i.state === step.id,
    ).length;
    list.append(
      append(
        el("li", null, {
          "data-kind": step.kind,
          "data-busy": count ? "true" : undefined,
        }),
        el("span", String(count), { class: "pipeline__count" }),
        el("span", step.label),
      ),
    );
  }
  const stuck = instances.filter(
    (i) => i.workflow === workflow.id && i.step.kind === "exception",
  ).length;
  append(
    box,
    list,
    stuck
      ? el("p", `${stuck} in an exception path`, { class: "pipeline__stuck" })
      : null,
  );
  return box;
}
function empty(title, text) {
  return append(
    el("div", null, { class: "empty" }),
    el("strong", title),
    text ? el("p", text) : null,
  );
}
function gaps() {
  const details = el("details", null, { class: "gaps" });
  append(
    details,
    el(
      "summary",
      `${application.unsupported.length} ${application.unsupported.length === 1 ? "capability needs" : "capabilities need"} setup`,
    ),
  );
  const list = el("ul");
  for (const gap of application.unsupported) list.append(el("li", gap));
  details.append(list);
  return details;
}
function instanceRow(instance) {
  const workflow = workflowOf(instance),
    status = statusOf(instance);
  const row = button(
    "",
    () => go({ page: "instance", id: instance.id }),
    "row",
    `Open ${workflow?.name}: ${instance.step.label}`,
  );
  append(
    row,
    append(
      el("span", null, { class: "row__main" }),
      el("strong", instance.step.label),
      el("small", `${workflow?.name ?? ""} · ${linkSummary(instance)}`),
    ),
    pill(status.text, status.tone),
  );
  return row;
}

/* ── tasks and boards ────────────────────────────────────────────────── */
async function tasks(body) {
  heading(
    body,
    "WORK",
    profile().tasks,
    "Tasks assigned to your role, with their current status and next action.",
    startButtons(),
  );
  const mine = instances.filter((i) => i.can_act);
  if (!mine.length) body.append(empty("Nothing is waiting for you right now."));
  const list = el("div", null, { class: "card list" });
  for (const instance of mine) list.append(instanceRow(instance));
  if (mine.length) body.append(list);
  const others = instances.filter((i) => !i.can_act && i.step.kind !== "end");
  if (others.length) {
    body.append(el("h2", "With someone else"));
    const rest = el("div", null, { class: "card list" });
    for (const instance of others.slice(0, 20))
      rest.append(instanceRow(instance));
    body.append(rest);
  }
}
async function workflowPage(body, workflow) {
  if (!workflow) return go({ page: "home" });
  const mine = instances.filter((i) => i.workflow === workflow.id);
  heading(
    body,
    "PROCESS",
    workflow.name,
    `${mine.filter((i) => i.step.kind !== "end").length} in progress · ${mine.filter((i) => i.step.kind === "end").length} finished`,
    startButtons().filter((node) =>
      node.textContent.toLowerCase().includes(workflow.name.toLowerCase()),
    ),
  );
  const toggle = el("div", null, {
    class: "segmented",
    role: "group",
    "aria-label": "View",
  });
  const asBoard = route.view ? route.view === "board" : profile().board;
  append(
    toggle,
    button(
      "Board",
      () => go({ ...route, view: "board" }),
      asBoard ? "active" : "",
    ),
    button(
      "List",
      () => go({ ...route, view: "list" }),
      asBoard ? "" : "active",
    ),
  );
  body.append(toggle);
  if (!mine.length)
    return body.append(
      empty(
        "Nothing here yet.",
        canStart(workflow)
          ? "Start the first one with the button above."
          : "Work appears here once the role that starts this process begins one.",
      ),
    );
  if (!asBoard) {
    const list = el("div", null, { class: "card list" });
    for (const instance of mine) list.append(instanceRow(instance));
    return body.append(list);
  }
  const board = el("div", null, {
    class: "board",
    role: "list",
    "aria-label": workflow.name + " board",
  });
  for (const step of columnsOf(workflow)) {
    const here = mine.filter((i) => i.state === step.id);
    if (step.kind === "exception" && !here.length) continue;
    const column = append(
      el("section", null, {
        class: "column",
        role: "listitem",
        "data-kind": step.kind,
        "aria-label": step.label,
      }),
      append(
        el("header"),
        el("strong", step.label),
        el("span", String(here.length), { class: "count" }),
        el("small", step.kind === "end" ? "finished" : roleName(step.role_id)),
      ),
    );
    for (const instance of here) {
      const status = statusOf(instance);
      const card = button(
        "",
        () => go({ page: "instance", id: instance.id }),
        "tile",
        "Open " + linkSummary(instance),
      );
      append(
        card,
        el("strong", linkSummary(instance)),
        append(
          el("span", null, { class: "tile__meta" }),
          pill(status.text, status.tone),
          el("small", "rev " + instance.revision),
        ),
      );
      column.append(card);
    }
    if (!here.length)
      column.append(el("p", "Empty", { class: "column__empty" }));
    board.append(column);
  }
  body.append(board);
}

/* ── one process instance ────────────────────────────────────────────── */
function conditionText(edge) {
  const c = edge.condition;
  return c.kind === "always"
    ? ""
    : ` when ${String(c.field).replaceAll("_", " ")} ${c.kind === "not_equals" ? "is not" : "is"} ${String(c.value).replaceAll("_", " ").toLowerCase()}`;
}
async function instanceDetail(body, instance) {
  if (!instance) return go({ page: "home" });
  const workflow = workflowOf(instance),
    status = statusOf(instance);
  const entityIds = [
    ...new Set([
      ...(instance.step.reads_entity_ids || []),
      ...(instance.step.writes_entity_ids || []),
    ]),
  ];
  await Promise.all(entityIds.map((id) => records(id).catch(() => [])));
  append(
    body,
    button(
      "← " + workflow.name,
      () => go({ page: "workflow", id: workflow.id }),
      "link back",
    ),
  );
  heading(
    body,
    workflow.name.toUpperCase(),
    instance.step.label,
    linkSummary(instance),
    [pill(status.text, status.tone)],
  );
  const path = columnsOf(workflow).filter((s) => s.kind !== "exception");
  const reached = new Set();
  const history = await api(`/instances/${instance.id}/history`);
  for (const event of history) {
    if (event.data.state) reached.add(event.data.state);
    for (const hop of event.data.path || []) {
      reached.add(hop.source);
      reached.add(hop.target);
    }
  }
  const stepper = el("ol", null, {
    class: "stepper",
    "aria-label": "Progress",
  });
  for (const step of path)
    stepper.append(
      append(
        el("li", null, {
          "data-state":
            step.id === instance.state
              ? "current"
              : reached.has(step.id)
                ? "done"
                : "todo",
          "aria-current": step.id === instance.state ? "step" : undefined,
        }),
        el("span", step.label),
      ),
    );
  body.append(stepper);
  if (instance.step.kind === "exception")
    body.append(
      el(
        "div",
        "This work is in an exception path: " +
          instance.step.label +
          ". Resolve it to return to the main flow.",
        { class: "notice error", role: "status" },
      ),
    );

  const layout = el("div", null, { class: "detail" });
  const intent = TASK_INTENT[instance.step.kind] || TASK_INTENT.action;
  const action = append(
    el("section", null, {
      class: "card action",
      "data-task": instance.step.kind,
    }),
    append(
      el("header", null, { class: "task-heading" }),
      taskIcon(instance.step.label),
      el(
        "span",
        instance.step.kind === "end"
          ? "OUTCOME"
          : instance.can_act
            ? "YOUR NEXT ACTION"
            : "AWAITING ACTION",
        { class: "eyebrow" },
      ),
      el("h2", intent[0]),
      el("p", intent[1], { class: "muted" }),
    ),
  );
  if (instance.step.kind !== "end")
    action.append(
      append(
        el("div", null, { class: "task-owner" }),
        el("span", "Responsible"),
        el("strong", roleName(instance.step.role_id)),
      ),
    );
  const links = {};
  for (const entityId of entityIds) {
    const entity = application.entities.find((e) => e.id === entityId);
    const select = el("select", null, {
      "aria-label": "Link " + (entity?.name || entityId),
    });
    select.append(
      el("option", "Select " + (entity?.name || entityId).toLowerCase(), {
        value: "",
      }),
    );
    try {
      for (const row of await records(entityId))
        select.append(
          el("option", recordLabel(entity, row), { value: row.id }),
        );
    } catch {
      select.append(el("option", "Not visible to your role", { value: "" }));
    }
    select.value = instance.links[entityId] || "";
    select.disabled = !instance.can_act;
    links[entityId] = select;
    const writes = (instance.step.writes_entity_ids || []).includes(entityId);
    const recordField = labelled(
      entity?.name || entityId,
      select,
      writes
        ? "Used and updated by this task."
        : "Reference information for this task.",
    );
    const open = button(
      writes && instance.can_act ? "Edit task details ↗" : "Open record ↗",
      () =>
        go({
          page: "record",
          entity: entityId,
          id: select.value,
          ...(writes && instance.can_act
            ? {
                task: {
                  instance_id: instance.id,
                  expected_revision: instance.revision,
                },
              }
            : {}),
        }),
      "link record-link",
    );
    open.disabled = !select.value;
    const preview = el("dl", null, { class: "task-record-preview" });
    const drawPreview = () => {
      preview.replaceChildren();
      const row = cache.get(entityId)?.find((item) => item.id === select.value);
      if (!row || !entity) return;
      for (const attribute of entity.attributes
        .filter(
          (attribute) => !attribute.key && row.data[attribute.id] !== undefined,
        )
        .slice(0, 4)) {
        preview.append(
          append(
            el("div"),
            el("dt", attribute.name),
            el("dd", format(attribute, row.data[attribute.id])),
          ),
        );
      }
    };
    select.addEventListener("change", () => {
      open.disabled = !select.value;
      drawPreview();
    });
    drawPreview();
    action.append(
      append(
        el("div", null, { class: "task-record" }),
        recordField,
        preview,
        open,
      ),
    );
  }
  if (instance.blocked?.length) {
    const box = append(
      el("div", null, {
        class: "blocked",
        role: "status",
        id: "blocked-reason",
      }),
      el("strong", "This step cannot be completed yet"),
    );
    const list = el("ul");
    for (const reason of instance.blocked)
      list.append(
        el(
          "li",
          reason.message
            .replace(/^This step cannot run yet: /, "")
            .replace(/ \([a-z0-9_]+\)$/, ""),
        ),
      );
    box.append(list);
    box.append(
      el(
        "p",
        instance.blocked.some((b) => b.decision)
          ? "The business owner records the decision in Design Studio; the application is then generated again. Nothing here guesses the answer."
          : "The specification has no executable logic for this yet. The application refuses the step rather than guess.",
        { class: "muted small" },
      ),
    );
    action.append(box);
  }
  if (instance.can_act && instance.blocked?.length) {
    const unavailable = el(
      "button",
      "Complete “" + instance.step.label + "” — unavailable",
      {
        type: "button",
        class: "primary",
        disabled: "true",
        "aria-describedby": "blocked-reason",
      },
    );
    action.append(unavailable);
  } else if (instance.can_act) {
    action.append(
      button(
        "Complete “" + instance.step.label + "”",
        async () => {
          const bindings = Object.fromEntries(
            Object.entries(links)
              .filter(([, input]) => input.value)
              .map(([key, input]) => [key, input.value]),
          );
          await api(`/instances/${instance.id}/advance`, {
            expected_revision: instance.revision,
            links: bindings,
          });
          instances = await api("/instances");
          const next = instances.find((i) => i.id === instance.id);
          await go({ page: "instance", id: instance.id });
          notify(
            next
              ? `Done. Now at “${next.step.label}”${next.can_act ? " — also yours." : ` with ${roleName(next.step.role_id)}.`}`
              : "Done.",
          );
        },
        "primary",
      ),
    );
  } else if (instance.step.kind !== "end")
    action.append(
      el(
        "p",
        `This step is performed by ${roleName(instance.step.role_id)}. Sign in as that role to continue it.`,
        { class: "muted" },
      ),
    );
  const next = workflow.transitions.filter(
    (edge) => edge.source === instance.state,
  );
  if (next.length) {
    const what = append(
      el("div", null, { class: "next" }),
      el("h3", "What happens next"),
    );
    const list = el("ul");
    for (const edge of next)
      list.append(
        el("li", stateLabel(workflow, edge.target) + conditionText(edge)),
      );
    what.append(list);
    if ((instance.step.rule_ids || []).length)
      what.append(
        el(
          "p",
          "The applicable business rules must be satisfied before this work can continue.",
          { class: "muted small" },
        ),
      );
    action.append(what);
  }
  const timeline = append(
    el("section", null, { class: "card" }),
    el("h2", "History"),
  );
  const list = el("ol", null, { class: "timeline" });
  for (const event of [...history].reverse()) {
    const who = roleName(event.actor.split(":").pop());
    const title =
      event.action === "process.start"
        ? `Started at “${stateLabel(workflow, event.data.state)}”`
        : event.action === "process.advance"
          ? (event.data.path || [])
              .map(
                (hop) =>
                  `${stateLabel(workflow, hop.source)} → ${stateLabel(workflow, hop.target)}`,
              )
              .join(", ")
          : event.action;
    const item = append(
      el("li"),
      el("strong", title),
      el("span", `${who} · ${time(event.at)}`),
    );
    const outputs = Object.entries(event.data.outputs || {});
    if (outputs.length)
      item.append(
        el(
          "small",
          "Decided: " +
            outputs
              .map(([key, value]) => `${key.replaceAll("_", " ")} = ${value}`)
              .join(", "),
        ),
      );
    list.append(item);
  }
  timeline.append(list);
  append(layout, action, timeline);
  body.append(layout);
}

/* ── what this application can do ────────────────────────────────────── */
const LEVEL = {
  implemented: ["Works", "done"],
  partial: ["Partly", "waiting"],
  unsupported: ["Not available", "blocked"],
};
const CATEGORY = {
  business_decision: "Waiting on a business decision",
  missing_logic: "No executable logic yet",
  imported_data: "Data that should come from another system",
  unset_status: "Status nothing sets",
  external_integration: "External system not connected",
};
async function about(body) {
  const report = application.report || {},
    coverage = report.coverage || {};
  heading(
    body,
    "THIS APPLICATION",
    "What it can do",
    "An honest account of what runs, what is an assumption and what is not available. It is generated from the same specification as the application itself.",
  );
  const stats = el("div", null, { class: "stats", role: "list" });
  for (const [label, value] of [
    ["Processes", coverage.workflows ?? 0],
    [
      "Steps that can complete",
      `${coverage.steps_runnable ?? 0} of ${coverage.steps ?? 0}`,
    ],
    [
      "Rules with logic",
      `${coverage.rules_with_logic ?? 0} of ${coverage.rules ?? 0}`,
    ],
    ["Rules that are assumptions", coverage.rules_assumed ?? 0],
  ]) {
    stats.append(
      append(
        el("article", null, { class: "stat", role: "listitem" }),
        el("span", label),
        el("strong", String(value)),
      ),
    );
  }
  body.append(stats);
  const caps = append(
    el("section", null, { class: "card" }),
    el("h2", "Capabilities"),
  );
  const table = el("table", null, { "aria-label": "Capabilities" });
  append(
    table,
    append(
      el("thead"),
      append(
        el("tr"),
        el("th", "Capability", { scope: "col" }),
        el("th", "Status", { scope: "col" }),
        el("th", "What that means", { scope: "col" }),
      ),
    ),
  );
  const tbody = el("tbody");
  table.append(tbody);
  for (const capability of report.capabilities || []) {
    const [text, tone] = LEVEL[capability.level] || [
      capability.level,
      "neutral",
    ];
    const cell = el("td");
    cell.append(pill(text, tone));
    append(
      tbody,
      append(
        el("tr", null, { tabindex: undefined }),
        el("td", capability.name, { class: "strong" }),
        cell,
        el("td", capability.note, { class: "wrap" }),
      ),
    );
  }
  caps.append(append(el("div", null, { class: "table-scroll" }), table));
  body.append(caps);
  const items = application.unsupported_items || [];
  const gaps = append(
    el("section", null, { class: "card" }),
    el("h2", `Not executable yet (${items.length})`),
  );
  if (!items.length)
    gaps.append(
      el(
        "p",
        "Nothing is blocked: every rule has executable logic and no value is waiting on another system.",
        { class: "muted" },
      ),
    );
  for (const category of Object.keys(CATEGORY)) {
    const those = items.filter((item) => item.category === category);
    if (!those.length) continue;
    const details = el("details");
    append(details, el("summary", `${CATEGORY[category]} (${those.length})`));
    const list = el("ul");
    for (const item of those.slice(0, 40))
      list.append(el("li", item.detail || item.text));
    if (those.length > 40)
      list.append(el("li", `and ${those.length - 40} more`));
    details.append(list);
    gaps.append(details);
  }
  gaps.append(
    el(
      "p",
      "The application refuses an action that depends on any of these instead of guessing. A rule marked as an assumption runs in this demonstration but is not company policy.",
      { class: "muted small" },
    ),
  );
  body.append(gaps);
  const built = append(
    el("section", null, { class: "card" }),
    el("h2", "Built from"),
  );
  const list = el("ul", null, { class: "built" });
  for (const pack of report.packs || [])
    list.append(
      el(
        "li",
        `${pack.title} · version ${pack.version} · ${pack.status === "approved" ? "approved" : "needs review"}${pack.synthetic ? " · synthetic reference knowledge" : ""}`,
      ),
    );
  if (!(report.packs || []).length)
    list.append(
      el(
        "li",
        "This application was designed from the conversation alone; no reference knowledge was used.",
      ),
    );
  built.append(list);
  body.append(built);
}

/* ── records ─────────────────────────────────────────────────────────── */
function recordLabel(entity, row) {
  const keyAttribute = entity?.attributes.find((a) => a.key);
  if (keyAttribute?.value_source === "system_generated") {
    // a generated id means nothing to a person: a short reference and the first thing they entered
    const populated = entity.attributes.filter(
      (a) =>
        !a.key &&
        row.data[a.id] != null &&
        row.data[a.id] !== "" &&
        a.value_source !== "system_generated",
    );
    const shown =
      populated.find((a) =>
        /name|title|subject|destination|reference/i.test(a.id + a.name),
      ) || populated[0];
    const reference =
      "#" + String(row.data[keyAttribute.id] ?? row.id).slice(0, 6);
    return shown
      ? `${reference} · ${format(shown, row.data[shown.id])}`
      : reference;
  }
  const key = keyAttribute?.id;
  const name = entity?.attributes.find(
    (a) => /name|title/i.test(a.id) && !a.key,
  )?.id;
  const value = row.data[key] ?? Object.values(row.data)[0] ?? row.id;
  return name && row.data[name]
    ? `${value} · ${row.data[name]}`
    : String(value);
}
const statusAttribute = (entity) =>
  entity.attributes.find(
    (a) => a.enum?.length && /status|state|stage/i.test(a.id + a.name),
  ) || entity.attributes.find((a) => a.enum?.length);
function format(attribute, value) {
  if (value === undefined || value === null || value === "") return "—";
  if (attribute.type === "boolean") return value ? "Yes" : "No";
  if (attribute.type === "datetime") return time(value);
  if (attribute.type === "date") return day(value);
  return String(value);
}
async function entityPage(body, entity) {
  if (!entity) return go({ page: "home" });
  heading(
    body,
    "RECORDS",
    entity.name,
    entity.description || "The records your processes work on.",
    entity.creatable
      ? [
          button(
            "Add record",
            () => go({ page: "record", entity: entity.id, id: "new" }),
            "primary",
            "Add a record to " + entity.name,
          ),
        ]
      : [],
  );
  let rows;
  try {
    rows = await records(entity.id);
  } catch (error) {
    return body.append(
      el(
        "div",
        error.status === 403
          ? "Your role cannot see these records."
          : error.message,
        { class: "notice error", role: "alert" },
      ),
    );
  }
  const status = statusAttribute(entity);
  const toolbar = el("div", null, { class: "toolbar" });
  const search = el("input", null, {
    type: "search",
    placeholder: "Search " + entity.name.toLowerCase(),
    "aria-label": "Search records",
  });
  const filter = status
    ? el("select", null, { "aria-label": "Filter by " + status.name })
    : null;
  if (filter) {
    filter.append(
      el("option", "All " + status.name.toLowerCase(), { value: "" }),
    );
    for (const value of status.enum)
      filter.append(el("option", value, { value }));
  }
  const counter = el("span", "", { class: "muted", role: "status" });
  append(toolbar, search, filter, counter);
  body.append(toolbar);
  if (!rows.length)
    return body.append(
      empty(
        "No records in " + entity.name + " yet.",
        entity.creatable
          ? "Add the first one to get started."
          : "Records appear here when a role that may create them adds one.",
      ),
    );
  if (status) {
    // how the records are spread over the status values, drawn from the data itself: a click filters the list
    const chips = el("div", null, {
      class: "chips",
      role: "group",
      "aria-label": status.name + " summary",
    });
    for (const value of status.enum) {
      const count = rows.filter((row) => row.data[status.id] === value).length;
      if (!count) continue;
      const chip = button(
        "",
        () => {
          filter.value = filter.value === value ? "" : value;
          filter.dispatchEvent(new Event("change"));
        },
        "chip",
        `${value}: ${count}`,
      );
      append(
        chip,
        el("strong", String(count)),
        el("span", value.replaceAll("_", " ").toLowerCase()),
      );
      chips.append(chip);
    }
    if (chips.childNodes.length) body.append(chips);
  }
  const columns = [
    ...entity.attributes.filter((a) => a.key),
    ...entity.attributes.filter((a) => !a.key && a !== status),
  ].slice(0, status ? 4 : 5);
  const table = el("table", null, { "aria-label": entity.name + " records" }),
    head = el("tr");
  for (const attribute of columns)
    head.append(el("th", attribute.name, { scope: "col" }));
  if (status) head.append(el("th", status.name, { scope: "col" }));
  head.append(el("th", "Revision", { scope: "col" }));
  append(table, append(el("thead"), head));
  const tbody = el("tbody");
  table.append(tbody);
  const draw = () => {
    tbody.replaceChildren();
    const query = search.value.toLowerCase();
    const shown = rows.filter(
      (row) =>
        JSON.stringify(row.data).toLowerCase().includes(query) &&
        (!filter?.value || row.data[status.id] === filter.value),
    );
    counter.textContent = `${shown.length} of ${rows.length}`;
    for (const row of shown) {
      const tr = el("tr", null, {
        tabindex: "0",
        "aria-label": "Open " + recordLabel(entity, row),
      });
      const open = () => go({ page: "record", entity: entity.id, id: row.id });
      tr.addEventListener("click", open);
      tr.addEventListener("keydown", (event) => {
        if (event.key === "Enter") open();
      });
      columns.forEach((attribute, index) =>
        tr.append(
          el(
            "td",
            format(attribute, row.data[attribute.id]),
            index === 0 ? { class: "strong" } : {},
          ),
        ),
      );
      if (status) {
        const cell = el("td");
        cell.append(pill(format(status, row.data[status.id]), "neutral"));
        tr.append(cell);
      }
      tr.append(el("td", String(row.revision), { class: "muted" }));
      tbody.append(tr);
    }
    if (!shown.length) {
      const tr = el("tr");
      tr.append(
        el("td", "No records match.", {
          colspan: String(columns.length + 2),
          class: "muted",
        }),
      );
      tbody.append(tr);
    }
  };
  search.addEventListener("input", draw);
  filter?.addEventListener("change", draw);
  draw();
  body.append(append(el("div", null, { class: "table-scroll card" }), table));
}
async function recordForm(body, entity, id, taskContext) {
  if (!entity) return go({ page: "home" });
  const task = taskContext
    ? instances.find((item) => item.id === taskContext.instance_id)
    : null;
  if (
    taskContext &&
    (!task || !task.can_act || task.revision !== taskContext.expected_revision)
  )
    throw new Error("The task changed. Reload it before editing.");
  const allowedFields =
    task?.step.input_fields == null
      ? null
      : new Set(task.step.input_fields[entity.id] || []);
  const allowedRelations = new Set(
    task?.step.input_relationships?.[entity.id] || [],
  );
  const back = () =>
    go(
      task
        ? { page: "instance", id: task.id }
        : { page: "records", id: entity.id },
    );
  const rows = await records(entity.id);
  const row = id === "new" ? null : rows.find((r) => r.id === id);
  if (id !== "new" && !row)
    throw new Error(
      "This record is no longer available to your role. Reload the record list.",
    );
  append(
    body,
    button("← " + (task?.step.label || entity.name), back, "link back"),
  );
  heading(
    body,
    entity.name.toUpperCase(),
    row ? recordLabel(entity, row) : "New record",
    row
      ? `Revision ${row.revision}. Review the details before saving.`
      : "Enter the record details. Fields marked * are required.",
  );
  const form = el("form", null, {
      class: "card record-form",
      novalidate: "true",
    }),
    fields = new Map();
  form.append(
    append(
      el("header", null, { class: "record-form__heading" }),
      el("span", "RECORD DETAILS", { class: "eyebrow" }),
      el("h2", task?.step.label || entity.name),
      el(
        "p",
        "Fields marked * are required. Changes are saved only when you choose Create record or Save changes.",
        { class: "muted" },
      ),
    ),
  );
  const errors = el("div", null, { class: "form-errors", role: "alert" });
  form.append(errors);
  const refs = application.references.filter((r) => r.source === entity.id);
  const attributes = [
    ...entity.attributes,
    ...refs
      .filter((r) => r.enforcement === "link")
      .map((r) => ({
        id: r.field,
        name:
          application.entities.find((e) => e.id === r.target)?.name ||
          r.target.replace(/^ent_/, "").replaceAll("_", " "),
        type: "string",
        required: r.required,
        writable: true,
      })),
  ];
  const otherRoles = el("details", null, { class: "record-form__other-roles" });
  const otherFields = el("div", null, { class: "record-form__other-fields" });
  append(
    otherRoles,
    el("summary", "Information managed by other roles"),
    el(
      "p",
      "These fields are available for context. Only their responsible roles can change them.",
      { class: "muted" },
    ),
    otherFields,
  );
  for (const attr of attributes) {
    if (attr.system_managed || attr.writable === false) continue;
    const reference = refs.find((r) => r.field === attr.id);
    if (
      allowedFields &&
      !(
        allowedFields.has(attr.id) ||
        (reference && allowedRelations.has(reference.relationship_id))
      )
    )
      continue;
    let input;
    if (reference || attr.enum?.length || attr.type === "boolean") {
      input = el("select");
      input.append(el("option", "Choose…", { value: "" }));
      if (reference) {
        try {
          for (const item of await records(reference.target))
            input.append(
              el(
                "option",
                recordLabel(
                  application.entities.find((e) => e.id === reference.target),
                  item,
                ),
                {
                  value:
                    reference.enforcement === "foreign_key"
                      ? item.data[reference.target_key]
                      : item.id,
                },
              ),
            );
        } catch {
          input.append(el("option", "Not visible to your role", { value: "" }));
          input.dataset.unavailable = "true";
        }
        if (input.options.length === 1 && reference.required)
          input.append(
            el("option", "None exist yet: they are created elsewhere", {
              value: "",
              disabled: "true",
            }),
          );
      } else
        for (const value of attr.type === "boolean"
          ? ["true", "false"]
          : attr.enum)
          input.append(
            el(
              "option",
              attr.type === "boolean"
                ? value === "true"
                  ? "Yes"
                  : "No"
                : value,
              { value },
            ),
          );
    } else {
      input = el("input", null, {
        type: ["integer", "decimal"].includes(attr.type)
          ? "number"
          : attr.type === "date"
            ? "date"
            : attr.type === "datetime"
              ? "datetime-local"
              : "text",
      });
      if (attr.type === "decimal") input.step = "any";
      if (attr.minimum != null) input.min = String(attr.minimum);
      if (attr.maximum != null) input.max = String(attr.maximum);
      if (attr.min_length != null) input.minLength = attr.min_length;
      if (attr.max_length != null) input.maxLength = attr.max_length;
    }
    input.value =
      row?.data[attr.id] == null
        ? ""
        : attr.type === "datetime"
          ? toLocalInput(row.data[attr.id])
          : String(row.data[attr.id]);
    input.required = Boolean(attr.required && !attr.allow_unknown);
    input.disabled =
      !entity.writable ||
      Boolean(row && attr.key) ||
      Boolean(
        attr.owner_role_id && attr.owner_role_id !== application.user.role,
      ) ||
      input.dataset.unavailable === "true";
    input.setAttribute("aria-label", attr.name);
    const hint =
      input.dataset.unavailable === "true"
        ? `Unavailable: your role cannot see ${attr.name} records, so another role links this.`
        : attr.owner_role_id && attr.owner_role_id !== application.user.role
          ? `Only ${roleName(attr.owner_role_id)} may change this.`
          : row && attr.key
            ? "Identifies the record; it cannot change."
            : attr.type === "datetime"
              ? `In your time zone (${ZONE}); saved as an exact moment in UTC.`
              : attr.type === "date"
                ? "A calendar date; no time zone applies."
                : attr.description;
    const label = labelled(
      attr.name + (input.required ? " *" : ""),
      input,
      hint,
    );
    const problem = el("span", "", {
      class: "field-error",
      id: "error-" + attr.id,
      role: "alert",
    });
    input.setAttribute("aria-describedby", "error-" + attr.id);
    label.append(problem);
    fields.set(attr.id, { input, attr, problem });
    if (attr.owner_role_id && attr.owner_role_id !== application.user.role)
      otherFields.append(label);
    else form.append(label);
  }
  if (otherFields.childNodes.length) form.append(otherRoles);
  const actions = el("div", null, { class: "form-actions" });
  const submit = el("button", row ? "Save changes" : "Create record", {
    type: "submit",
    class: "primary",
  });
  submit.disabled =
    !entity.writable ||
    ![...fields.values()].some(({ input }) => !input.disabled);
  append(
    actions,
    submit,
    button("Cancel", back, "ghost"),
    !entity.writable
      ? el("span", "Your role can read these records but not change them.", {
          class: "muted",
        })
      : null,
  );
  form.append(actions);
  const snapshot = () =>
    JSON.stringify(
      [...fields.values()]
        .filter(({ input }) => !input.disabled)
        .map(({ input }) => input.value),
    );
  const initialValues = snapshot();
  const edited = () => {
    dirty = snapshot() !== initialValues;
  };
  form.addEventListener("input", edited);
  form.addEventListener("change", edited);
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    errors.textContent = "";
    for (const { input, problem } of fields.values()) {
      problem.textContent = "";
      input.removeAttribute("aria-invalid");
    }
    const flag = (key, message) => {
      const field = fields.get(key);
      if (field) {
        field.problem.textContent = message;
        field.input.setAttribute("aria-invalid", "true");
      }
    };
    const missing = [...fields.entries()].filter(
      ([, { input }]) =>
        input.required && !input.disabled && input.value === "",
    );
    for (const [key] of missing) flag(key, "Required.");
    const badTimes = [...fields.entries()].filter(
      ([, { input, attr }]) =>
        attr.type === "datetime" &&
        input.value !== "" &&
        fromLocalInput(input.value) === null,
    );
    for (const [key] of badTimes) flag(key, "Enter a complete date and time.");
    if (missing.length || badTimes.length) {
      errors.textContent =
        "Some fields need attention: " +
        [...missing, ...badTimes].map(([, { attr }]) => attr.name).join(", ") +
        ".";
      form.querySelector("[aria-invalid=true]")?.focus();
      return;
    }
    submit.disabled = true;
    savingRecord = true;
    submit.textContent = "Saving…";
    form.setAttribute("aria-busy", "true");
    try {
      const data = {};
      for (const [key, { input, attr }] of fields) {
        if (attr.owner_role_id && attr.owner_role_id !== application.user.role)
          continue;
        if (input.disabled) continue;
        if (input.value === "") {
          if (row && row.data[key] != null) data[key] = null;
          continue;
        } // clearing an optional field really clears it
        data[key] = ["integer", "decimal"].includes(attr.type)
          ? Number(input.value)
          : attr.type === "boolean"
            ? input.value === "true"
            : attr.type === "datetime"
              ? fromLocalInput(input.value)
              : input.value;
      }
      const savedRecord = await api(
        "/records/" + entity.id + (row ? "/" + row.id : ""),
        {
          data,
          ...(row ? { expected_revision: row.revision } : {}),
          ...(taskContext ? { task_context: taskContext } : {}),
        },
      );
      dirty = false;
      savingRecord = false;
      const previousRecords = cache.get(entity.id) || [];
      cache.set(
        entity.id,
        row
          ? previousRecords.map((record) =>
              record.id === savedRecord.id ? savedRecord : record,
            )
          : [...previousRecords, savedRecord],
      );
      let refreshed = true;
      try {
        instances = await api("/instances");
      } catch {
        refreshed = false;
      }
      await back();
      notify(
        (row ? "Changes saved." : "Record created in " + entity.name + ".") +
          (refreshed ? "" : " Refresh the page to update process status."),
      );
    } catch (error) {
      for (const detail of error.details || [])
        flag(detail.field, detail.message);
      form.querySelector("[aria-invalid=true]")?.focus();
      errors.textContent =
        error.status === 409
          ? error.message + " Reload to see the latest version."
          : error.details?.length
            ? "Check the highlighted fields and try again."
            : error.message;
    } finally {
      savingRecord = false;
      form.removeAttribute("aria-busy");
      submit.textContent = row ? "Save changes" : "Create record";
      submit.disabled =
        !entity.writable ||
        ![...fields.values()].some(({ input }) => !input.disabled);
    }
  });
  body.append(form);
  if (row) {
    const history = await api(
      "/records/" + entity.id + "/" + row.id + "/history",
    );
    const disclosure = el("details", null, { class: "card record-history" });
    disclosure.append(
      el("summary", "Record history · " + history.length + " changes"),
    );
    const list = el("ol");
    for (const event of history) {
      const fieldsChanged = (event.data.changed_fields || []).map(
        (id) => entity.attributes.find((a) => a.id === id)?.name || id,
      );
      list.append(
        append(
          el("li"),
          el("strong", event.action.replaceAll(".", " ")),
          el("p", event.actor + " · " + new Date(event.at).toLocaleString()),
          el(
            "p",
            fieldsChanged.length
              ? "Changed: " + fieldsChanged.join(", ")
              : "Revision " + event.data.revision,
          ),
        ),
      );
    }
    disclosure.append(list);
    body.append(disclosure);
  }
}

load()
  .catch(() => signIn())
  .catch((error) => {
    root.replaceChildren(el("p", error.message, { role: "alert" }));
  });
