# Build and check this export

This archive was generated from an approved Design Studio specification. Nothing in it has been built or run at export.

1. `npm install` (needs network access to the npm registry).
2. `npm run typecheck`: compiles every TypeScript file, including `src/generated/`.
3. `npm test`: runs `src/generated/validation.test.ts`. The expected results were computed by the Design Studio server,
   so a pass shows the generated validation agrees with the server's rules.
4. `npm run dev`: opens the screen mockup. Inputs are disabled and no business action is connected.

What each file is (executable, preview, contract, manifest) is listed in `design/artifacts.json`, together with what is
not generated: there is no backend implementation, database migration, integration adapter or access enforcement.
Files under `src/generated/`, `schemas/`, `api/` and `design/` are replaced on the next export; keep your own code elsewhere.

## Runnable local application

The compiler also generated runtime/. Run its Python server and independent tests as documented in runtime/README.md. It requires no npm packages. The npm commands above concern the separate React design preview and validation library.
