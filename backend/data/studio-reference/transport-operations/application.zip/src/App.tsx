import React from 'react'
import definition from './definition.json'

// Review-only mockup. This template never calls commerce APIs or executes events.
type Node = { kind: string; id: string; props: Record<string, unknown>; children?: Node[] | null }
function NodeView({ node }: { node: Node }) {
  switch (node.kind) {
    case 'container': return <section><h2>{String(node.props.title)}</h2>{node.children?.map(child => <NodeView key={child.id} node={child} />)}</section>
    case 'text': return <p>{String(node.props.content)}</p>
    case 'field': {
      // Validation metadata is shown, never executed: required fields are marked and carry the required attribute.
      const required = Array.isArray(node.props.validations) && node.props.validations.some(rule => (rule as { kind?: unknown }).kind === 'required')
      return <label>{String(node.props.label)}{required ? ' *' : ''}<input disabled required={required} aria-required={required} placeholder="Mockup only" />{node.props.help_text ? <small>{String(node.props.help_text)}</small> : null}</label>
    }
    case 'table': return <section><h2>{String(node.props.title)}</h2><p>No live data</p></section>
    case 'button': return <button type="button" disabled>{String(node.props.label)}</button>
    default: return null
  }
}
type Workflow = { id: string; name: string; states: { id: string; label: string; kind: string }[]
  transitions: { id: string; source: string; target: string; condition: { kind: string; field: string | null; value: unknown } }[] }
// Workflows are listed for review only; conditions are shown as text and never evaluated.
function WorkflowView({ workflow }: { workflow: Workflow }) {
  return <section><h2>Workflow: {workflow.name}</h2>
    <ol>{workflow.states.map(state => <li key={state.id}>{state.label} ({state.kind})</li>)}</ol>
    <ul>{workflow.transitions.map(edge => <li key={edge.id}>{edge.source} → {edge.target}{edge.condition.kind === 'always' ? '' : ` when ${edge.condition.field} ${edge.condition.kind === 'equals' ? '=' : '≠'} ${String(edge.condition.value)}`}</li>)}</ul>
  </section>
}
export default function App() {
  const workflows = ((definition as { workflow_definitions?: Workflow[] }).workflow_definitions ?? [])
  return <main><p>MOCKUP ONLY — no business actions</p>{definition.screens.map(screen =>
    <section key={screen.id}><h1>{screen.title}</h1>{screen.components.map(node => <NodeView key={node.id} node={node} />)}</section>)}
    {workflows.map(workflow => <WorkflowView key={workflow.id} workflow={workflow} />)}</main>
}
