export type ReferenceRule = { field: string; target: string; required: boolean; relationship_id: string; enforcement: 'foreign_key' | 'link' }
export type ReferenceError = { field: string; code: 'reference_required' | 'reference_missing'; message: string }

/** Foreign-key references per entity, compiled from the specification's relationships. */
export const REFERENCES: Record<string, ReferenceRule[]> = {
  "ent_eco_order": [
    {
      "enforcement": "link",
      "field": "rel_eco_order_customer",
      "relationship_id": "rel_eco_order_customer",
      "required": true,
      "target": "ent_core_customer"
    }
  ],
  "ent_tms_shipment": [
    {
      "enforcement": "link",
      "field": "rel_tms_shipment_carrier",
      "relationship_id": "rel_tms_shipment_carrier",
      "required": false,
      "target": "ent_tms_carrier"
    },
    {
      "enforcement": "link",
      "field": "rel_tms_shipment_order",
      "relationship_id": "rel_tms_shipment_order",
      "required": true,
      "target": "ent_eco_order"
    },
    {
      "enforcement": "link",
      "field": "rel_tms_shipment_pack_unit",
      "relationship_id": "rel_tms_shipment_pack_unit",
      "required": false,
      "target": "ent_wms_pack_unit"
    },
    {
      "enforcement": "link",
      "field": "rel_tms_shipment_vehicle",
      "relationship_id": "rel_tms_shipment_vehicle",
      "required": false,
      "target": "ent_tms_vehicle"
    }
  ],
  "ent_tms_vehicle": [
    {
      "enforcement": "link",
      "field": "rel_tms_vehicle_carrier",
      "relationship_id": "rel_tms_vehicle_carrier",
      "required": true,
      "target": "ent_tms_carrier"
    }
  ],
  "ent_wms_pack_unit": [
    {
      "enforcement": "link",
      "field": "rel_wms_pack_unit_pick_list",
      "relationship_id": "rel_wms_pack_unit_pick_list",
      "required": true,
      "target": "ent_wms_pick_list"
    }
  ],
  "ent_wms_pick_list": [
    {
      "enforcement": "link",
      "field": "rel_wms_pick_list_location",
      "relationship_id": "rel_wms_pick_list_location",
      "required": true,
      "target": "ent_core_location"
    },
    {
      "enforcement": "link",
      "field": "rel_wms_pick_list_order",
      "relationship_id": "rel_wms_pick_list_order",
      "required": true,
      "target": "ent_eco_order"
    }
  ]
}

/** Required references must be present; every reference must resolve to an existing record (`exists` is supplied by the caller). */
export function validateReferences(entity: string, record: Record<string, unknown>, exists: (target: string, id: unknown) => boolean): ReferenceError[] {
  const errors: ReferenceError[] = []
  for (const rule of REFERENCES[entity] ?? []) {
    const value = record[rule.field]
    if (value === undefined || value === null || value === '') {
      if (rule.required) errors.push({ field: rule.field, code: 'reference_required', message: `${rule.field} must reference a ${rule.target}.` })
    } else if (!exists(rule.target, value)) errors.push({ field: rule.field, code: 'reference_missing', message: `No ${rule.target} has ${rule.field} = ${String(value)}.` })
  }
  return errors
}
