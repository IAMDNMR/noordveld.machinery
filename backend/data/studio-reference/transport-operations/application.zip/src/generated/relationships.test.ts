import { describe, expect, it } from 'vitest'
import { validateReferences } from './relationships'

// Expected results were computed by the Design Studio server's reference validation.
const CASES: { entity: string; description: string; record: Record<string, unknown>; existing: Record<string, unknown[]>; expected: string[] }[] = [
  {
    "description": "all references resolve",
    "entity": "ent_eco_order",
    "existing": {
      "ent_core_customer": [
        "ent_core_customer-1"
      ]
    },
    "expected": [],
    "record": {
      "rel_eco_order_customer": "ent_core_customer-1"
    }
  },
  {
    "description": "rel_eco_order_customer must exist",
    "entity": "ent_eco_order",
    "existing": {
      "ent_core_customer": [
        "ent_core_customer-1"
      ]
    },
    "expected": [
      "rel_eco_order_customer:reference_missing"
    ],
    "record": {
      "rel_eco_order_customer": "missing-id"
    }
  },
  {
    "description": "rel_eco_order_customer is required",
    "entity": "ent_eco_order",
    "existing": {
      "ent_core_customer": [
        "ent_core_customer-1"
      ]
    },
    "expected": [
      "rel_eco_order_customer:reference_required"
    ],
    "record": {}
  },
  {
    "description": "all references resolve",
    "entity": "ent_tms_shipment",
    "existing": {
      "ent_eco_order": [
        "ent_eco_order-1"
      ],
      "ent_tms_carrier": [
        "ent_tms_carrier-1"
      ],
      "ent_tms_vehicle": [
        "ent_tms_vehicle-1"
      ],
      "ent_wms_pack_unit": [
        "ent_wms_pack_unit-1"
      ]
    },
    "expected": [],
    "record": {
      "rel_tms_shipment_carrier": "ent_tms_carrier-1",
      "rel_tms_shipment_order": "ent_eco_order-1",
      "rel_tms_shipment_pack_unit": "ent_wms_pack_unit-1",
      "rel_tms_shipment_vehicle": "ent_tms_vehicle-1"
    }
  },
  {
    "description": "rel_tms_shipment_carrier must exist",
    "entity": "ent_tms_shipment",
    "existing": {
      "ent_eco_order": [
        "ent_eco_order-1"
      ],
      "ent_tms_carrier": [
        "ent_tms_carrier-1"
      ],
      "ent_tms_vehicle": [
        "ent_tms_vehicle-1"
      ],
      "ent_wms_pack_unit": [
        "ent_wms_pack_unit-1"
      ]
    },
    "expected": [
      "rel_tms_shipment_carrier:reference_missing"
    ],
    "record": {
      "rel_tms_shipment_carrier": "missing-id",
      "rel_tms_shipment_order": "ent_eco_order-1",
      "rel_tms_shipment_pack_unit": "ent_wms_pack_unit-1",
      "rel_tms_shipment_vehicle": "ent_tms_vehicle-1"
    }
  },
  {
    "description": "rel_tms_shipment_order must exist",
    "entity": "ent_tms_shipment",
    "existing": {
      "ent_eco_order": [
        "ent_eco_order-1"
      ],
      "ent_tms_carrier": [
        "ent_tms_carrier-1"
      ],
      "ent_tms_vehicle": [
        "ent_tms_vehicle-1"
      ],
      "ent_wms_pack_unit": [
        "ent_wms_pack_unit-1"
      ]
    },
    "expected": [
      "rel_tms_shipment_order:reference_missing"
    ],
    "record": {
      "rel_tms_shipment_carrier": "ent_tms_carrier-1",
      "rel_tms_shipment_order": "missing-id",
      "rel_tms_shipment_pack_unit": "ent_wms_pack_unit-1",
      "rel_tms_shipment_vehicle": "ent_tms_vehicle-1"
    }
  },
  {
    "description": "rel_tms_shipment_order is required",
    "entity": "ent_tms_shipment",
    "existing": {
      "ent_eco_order": [
        "ent_eco_order-1"
      ],
      "ent_tms_carrier": [
        "ent_tms_carrier-1"
      ],
      "ent_tms_vehicle": [
        "ent_tms_vehicle-1"
      ],
      "ent_wms_pack_unit": [
        "ent_wms_pack_unit-1"
      ]
    },
    "expected": [
      "rel_tms_shipment_order:reference_required"
    ],
    "record": {
      "rel_tms_shipment_carrier": "ent_tms_carrier-1",
      "rel_tms_shipment_pack_unit": "ent_wms_pack_unit-1",
      "rel_tms_shipment_vehicle": "ent_tms_vehicle-1"
    }
  },
  {
    "description": "rel_tms_shipment_pack_unit must exist",
    "entity": "ent_tms_shipment",
    "existing": {
      "ent_eco_order": [
        "ent_eco_order-1"
      ],
      "ent_tms_carrier": [
        "ent_tms_carrier-1"
      ],
      "ent_tms_vehicle": [
        "ent_tms_vehicle-1"
      ],
      "ent_wms_pack_unit": [
        "ent_wms_pack_unit-1"
      ]
    },
    "expected": [
      "rel_tms_shipment_pack_unit:reference_missing"
    ],
    "record": {
      "rel_tms_shipment_carrier": "ent_tms_carrier-1",
      "rel_tms_shipment_order": "ent_eco_order-1",
      "rel_tms_shipment_pack_unit": "missing-id",
      "rel_tms_shipment_vehicle": "ent_tms_vehicle-1"
    }
  },
  {
    "description": "rel_tms_shipment_vehicle must exist",
    "entity": "ent_tms_shipment",
    "existing": {
      "ent_eco_order": [
        "ent_eco_order-1"
      ],
      "ent_tms_carrier": [
        "ent_tms_carrier-1"
      ],
      "ent_tms_vehicle": [
        "ent_tms_vehicle-1"
      ],
      "ent_wms_pack_unit": [
        "ent_wms_pack_unit-1"
      ]
    },
    "expected": [
      "rel_tms_shipment_vehicle:reference_missing"
    ],
    "record": {
      "rel_tms_shipment_carrier": "ent_tms_carrier-1",
      "rel_tms_shipment_order": "ent_eco_order-1",
      "rel_tms_shipment_pack_unit": "ent_wms_pack_unit-1",
      "rel_tms_shipment_vehicle": "missing-id"
    }
  },
  {
    "description": "all references resolve",
    "entity": "ent_tms_vehicle",
    "existing": {
      "ent_tms_carrier": [
        "ent_tms_carrier-1"
      ]
    },
    "expected": [],
    "record": {
      "rel_tms_vehicle_carrier": "ent_tms_carrier-1"
    }
  },
  {
    "description": "rel_tms_vehicle_carrier must exist",
    "entity": "ent_tms_vehicle",
    "existing": {
      "ent_tms_carrier": [
        "ent_tms_carrier-1"
      ]
    },
    "expected": [
      "rel_tms_vehicle_carrier:reference_missing"
    ],
    "record": {
      "rel_tms_vehicle_carrier": "missing-id"
    }
  },
  {
    "description": "rel_tms_vehicle_carrier is required",
    "entity": "ent_tms_vehicle",
    "existing": {
      "ent_tms_carrier": [
        "ent_tms_carrier-1"
      ]
    },
    "expected": [
      "rel_tms_vehicle_carrier:reference_required"
    ],
    "record": {}
  },
  {
    "description": "all references resolve",
    "entity": "ent_wms_pack_unit",
    "existing": {
      "ent_wms_pick_list": [
        "ent_wms_pick_list-1"
      ]
    },
    "expected": [],
    "record": {
      "rel_wms_pack_unit_pick_list": "ent_wms_pick_list-1"
    }
  },
  {
    "description": "rel_wms_pack_unit_pick_list must exist",
    "entity": "ent_wms_pack_unit",
    "existing": {
      "ent_wms_pick_list": [
        "ent_wms_pick_list-1"
      ]
    },
    "expected": [
      "rel_wms_pack_unit_pick_list:reference_missing"
    ],
    "record": {
      "rel_wms_pack_unit_pick_list": "missing-id"
    }
  },
  {
    "description": "rel_wms_pack_unit_pick_list is required",
    "entity": "ent_wms_pack_unit",
    "existing": {
      "ent_wms_pick_list": [
        "ent_wms_pick_list-1"
      ]
    },
    "expected": [
      "rel_wms_pack_unit_pick_list:reference_required"
    ],
    "record": {}
  },
  {
    "description": "all references resolve",
    "entity": "ent_wms_pick_list",
    "existing": {
      "ent_core_location": [
        "ent_core_location-1"
      ],
      "ent_eco_order": [
        "ent_eco_order-1"
      ]
    },
    "expected": [],
    "record": {
      "rel_wms_pick_list_location": "ent_core_location-1",
      "rel_wms_pick_list_order": "ent_eco_order-1"
    }
  },
  {
    "description": "rel_wms_pick_list_location must exist",
    "entity": "ent_wms_pick_list",
    "existing": {
      "ent_core_location": [
        "ent_core_location-1"
      ],
      "ent_eco_order": [
        "ent_eco_order-1"
      ]
    },
    "expected": [
      "rel_wms_pick_list_location:reference_missing"
    ],
    "record": {
      "rel_wms_pick_list_location": "missing-id",
      "rel_wms_pick_list_order": "ent_eco_order-1"
    }
  },
  {
    "description": "rel_wms_pick_list_location is required",
    "entity": "ent_wms_pick_list",
    "existing": {
      "ent_core_location": [
        "ent_core_location-1"
      ],
      "ent_eco_order": [
        "ent_eco_order-1"
      ]
    },
    "expected": [
      "rel_wms_pick_list_location:reference_required"
    ],
    "record": {
      "rel_wms_pick_list_order": "ent_eco_order-1"
    }
  },
  {
    "description": "rel_wms_pick_list_order must exist",
    "entity": "ent_wms_pick_list",
    "existing": {
      "ent_core_location": [
        "ent_core_location-1"
      ],
      "ent_eco_order": [
        "ent_eco_order-1"
      ]
    },
    "expected": [
      "rel_wms_pick_list_order:reference_missing"
    ],
    "record": {
      "rel_wms_pick_list_location": "ent_core_location-1",
      "rel_wms_pick_list_order": "missing-id"
    }
  },
  {
    "description": "rel_wms_pick_list_order is required",
    "entity": "ent_wms_pick_list",
    "existing": {
      "ent_core_location": [
        "ent_core_location-1"
      ],
      "ent_eco_order": [
        "ent_eco_order-1"
      ]
    },
    "expected": [
      "rel_wms_pick_list_order:reference_required"
    ],
    "record": {
      "rel_wms_pick_list_location": "ent_core_location-1"
    }
  }
]

describe('generated reference validation agrees with the server', () => {
  for (const item of CASES) it(`${item.entity}: ${item.description}`, () => {
    const exists = (target: string, id: unknown) => (item.existing[target] ?? []).includes(id)
    expect(validateReferences(item.entity, item.record, exists).map(error => `${error.field}:${error.code}`)).toEqual(item.expected)
  })
})
